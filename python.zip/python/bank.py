import tkinter as tk
from tkinter import messagebox
import csv
import os
import hashlib

CSV_FILE = "bank_users.csv"

# Function to hash the password
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Sign up function with password hashing
def save_user():
    username = e_user.get()
    password = e_pass.get()

    if not username or not password:
        messagebox.showwarning("Input Error", "All fields are required!")
        return

    if os.path.exists(CSV_FILE):
        with open(CSV_FILE, 'r') as file:
            reader = csv.reader(file)
            for row in reader:
                if row[0] == username:
                    messagebox.showerror("Error", "Username already exists!")
                    return

    hashed_password = hash_password(password)
    with open(CSV_FILE, 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([username, hashed_password])
    
    messagebox.showinfo("Success", "Sign Up Successful!")
    clear_entries()

# Login function compares hashed password
def login_user():
    username = e_user.get()
    password = e_pass.get()

    if not username or not password:
        messagebox.showwarning("Input Error", "All fields are required!")
        return

    if not os.path.exists(CSV_FILE):
        messagebox.showerror("Error", "No users found. Please sign up first.")
        return

    hashed_password = hash_password(password)

    with open(CSV_FILE, 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            if row[0] == username and row[1] == hashed_password:
                messagebox.showinfo("Login Success", f"Welcome, {username}!")
                clear_entries()
                return

    messagebox.showerror("Login Failed", "Invalid username or password.")

# Clear input fields
def clear_entries():
    e_user.delete(0, tk.END)
    e_pass.delete(0, tk.END)

# GUI setup
root = tk.Tk()
root.title("Bank Login System (Secure)")
root.geometry("400x300")
root.config(bg="lightblue")

tk.Label(root, text="Bank Login Form", font=("Arial", 16, "bold"), bg="lightblue").pack(pady=10)

tk.Label(root, text="Username:", bg="lightblue", font=("Arial", 12)).pack()
e_user = tk.Entry(root, font=("Arial", 12))
e_user.pack(pady=5)

tk.Label(root, text="Password:", bg="lightblue", font=("Arial", 12)).pack()
e_pass = tk.Entry(root, show="*", font=("Arial", 12))
e_pass.pack(pady=5)

tk.Button(root, text="Login", command=login_user, width=15, bg="green", fg="white").pack(pady=10)
tk.Button(root, text="Sign Up", command=save_user, width=15, bg="blue", fg="white").pack()

root.mainloop()
