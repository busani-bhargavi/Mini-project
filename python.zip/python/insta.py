import tkinter as tk
root=tk.Tk()
root.geometry('900x600')
root.title("my application")
root.config(bg='gray')

m1=tk.Label(root,text="INSTAGRAM",font=("algerian",20,"bold"))
m1.place(x=550,y=50)

m2=tk.Label(root,text="Login page",font=("algerian",10))
m2.place(x=600,y=100)

m3=tk.Label(root,text="UserName", bg="lightpink",font=("algerian",16))
m3.place(x=500,y=200)

e1=tk.Entry(root,font=("arial",16))
e1.place(x=650,y=200)

m4=tk.Label(root,text="PASSWORD",bg="lightpink",font=("algerian",16))
m4.place(x=500,y=300)

e2=tk.Entry(root,font=("arial",16))
e2.place(x=650,y=300)

b1=tk.Button(root,text="LOGIN", bg="lightpink",font=("arial",10))
b1.place(x=500,y=350)

b2=tk.Button(root,text="SINGH UP", bg="lightpink",font=("arial",10))
b2.place(x=600,y=350)


root.mainloop()
