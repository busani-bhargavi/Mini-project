import tkinter as tk
from tkinter import messagebox
import random

# Board path (simplified for 1D path of 20 cells)
BOARD_PATH = [(i*40 + 20, 200) for i in range(20)]

# Initial setup
current_player = "Red"
positions = {"Red": -1, "Green": -1}

def roll_dice():
    global current_player
    roll = random.randint(1, 6)
    dice_label.config(text=f"Dice: {roll}")
    
    # Get current position
    pos = positions[current_player]
    if pos + roll < len(BOARD_PATH):
        positions[current_player] += roll
        move_token(current_player)
        check_win()
    else:
        messagebox.showinfo("Turn Skipped", f"{current_player} can't move.")
    
    # Switch turn
    current_player = "Green" if current_player == "Red" else "Red"
    turn_label.config(text=f"Turn: {current_player}")

def move_token(player):
    pos = positions[player]
    x, y = BOARD_PATH[pos]
    if player == "Red":
        canvas.coords(red_token, x-10, y-10, x+10, y+10)
    else:
        canvas.coords(green_token, x-10, y+10, x+10, y+30)

def check_win():
    for player, pos in positions.items():
        if pos == len(BOARD_PATH) - 1:
            messagebox.showinfo("Game Over", f"{player} wins!")
            reset_game()

def reset_game():
    global positions, current_player
    positions = {"Red": -1, "Green": -1}
    current_player = "Red"
    canvas.coords(red_token, 20-10, 200-10, 20+10, 200+10)
    canvas.coords(green_token, 20-10, 200+10, 20+10, 200+30)
    dice_label.config(text="Dice: -")
    turn_label.config(text="Turn: Red")

# Tkinter window
root = tk.Tk()
root.title("Ludo Game (Simplified)")
root.geometry("900x400")

canvas = tk.Canvas(root, width=900, height=300, bg="white")
canvas.pack()

# Draw path
for x, y in BOARD_PATH:
    canvas.create_rectangle(x-20, y-20, x+20, y+20, outline="black", width=2)

# Create tokens
red_token = canvas.create_oval(10, 190, 30, 210, fill="red")
green_token = canvas.create_oval(10, 210, 30, 230, fill="green")

# Controls
dice_label = tk.Label(root, text="Dice: -", font=("Arial", 16))
dice_label.pack()

turn_label = tk.Label(root, text="Turn: Red", font=("Arial", 16))
turn_label.pack()

roll_btn = tk.Button(root, text="Roll Dice", font=("Arial", 14), command=roll_dice)
roll_btn.pack(pady=10)

reset_btn = tk.Button(root, text="Reset Game", command=reset_game)
reset_btn.pack()

root.mainloop()
