score=int(input("enter the score:"))
if score==6:
    print("vk hit 6")
elif score==4:
    print("vk hit 4")
elif score==3:
    print("vk hit 3")
elif score==2:
    print("vk hit 2")  
elif score==1:
    print("vk hit 1") 
elif score==0:
    print("dot ball")    
else:
    print(wicket)