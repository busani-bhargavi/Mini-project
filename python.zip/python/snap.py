import tkinter as tk
from tkinter import messagebox
import csv
import hashlib
import os

CSV_FILE = "users.csv"

# Hashing function
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# ----------------- SIGN UP FUNCTION ----------------
def sign_up():
    username = entry_username.get()
    password = entry_password.get()

    if not username or not password:
        messagebox.showwarning("Missing Info", "Username and password required.")
        return

    # Check if user already exists
    if os.path.exists(CSV_FILE):
        with open(CSV_FILE, 'r') as file:
            reader = csv.reader(file)
            for row in reader:
                if row[0] == username:
                    messagebox.showerror("Error", "Username already taken!")
                    return

    hashed_pass = hash_password(password)
    with open(CSV_FILE, 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([username, hashed_pass])

    messagebox.showinfo("Success", "Account created! You can now login.")
    clear_entries()

# ----------------- LOGIN FUNCTION ----------------
def login():
    username = entry_username.get()
    password = entry_password.get()

    if not username or not password:
        messagebox.showwarning("Missing Info", "Username and password required.")
        return

    if not os.path.exists(CSV_FILE):
        messagebox.showerror("Error", "No users found. Please sign up first.")
        return

    hashed_pass = hash_password(password)
    with open(CSV_FILE, 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            if row[0] == username and row[1] == hashed_pass:
                messagebox.showinfo("Welcome", f"Welcome back, {username}!")
                clear_entries()
                return

    messagebox.showerror("Failed", "Invalid login credentials.")

# ----------------- CLEAR FIELDS ----------------
def clear_entries():
    entry_username.delete(0, tk.END)
    entry_password.delete(0, tk.END)

# ----------------- GUI ----------------
root = tk.Tk()
root.title("Snapchat Login")
root.geometry("400x400")
root.config(bg="yellow")

# Title Label (Snapchat Style)
tk.Label(root, text="Snapchat", font=("Comic Sans MS", 24, "bold"), bg="yellow", fg="black").pack(pady=20)

# Username
tk.Label(root, text="Username:", font=("Arial", 12), bg="yellow").pack()
entry_username = tk.Entry(root, font=("Arial", 12))
entry_username.pack(pady=5)

# Password
tk.Label(root, text="Password:", font=("Arial", 12), bg="yellow").pack()
entry_password = tk.Entry(root, font=("Arial", 12), show="*")
entry_password.pack(pady=5)

# Buttons
tk.Button(root, text="Login", command=login, bg="black", fg="white", width=20).pack(pady=10)
tk.Button(root, text="Sign Up", command=sign_up, bg="white", fg="black", width=20).pack()

# Footer
tk.Label(root, text="Not the real Snapchat™", font=("Arial", 8), bg="yellow", fg="gray").pack(side="bottom", pady=10)

root.mainloop()
